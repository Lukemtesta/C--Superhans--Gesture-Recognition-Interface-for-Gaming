﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Timers;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace WindowsFormsApplication1
{
    class TextureGroups
    {
        TextureGroups()
        { }

        ~TextureGroups()
        { }

        void MenuGroupOne()
        {
            const int NoImages = 3;

            // Load Picture Names

            string[] Menu = new String[NoImages];
            Menu[0] = "Setup.png";
            Menu[1] = "Connectivity.png";
            Menu[2] = "Exit.png";

            // Point to associate PictureBox

            PictureBox[] pictureBoxes = new PictureBox[NoImages];
        }
    }
}
