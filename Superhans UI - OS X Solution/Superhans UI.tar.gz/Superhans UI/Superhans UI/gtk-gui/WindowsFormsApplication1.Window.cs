
namespace WindowsFormsApplication1
{
	public partial class Window
	{
	}
}
